#Récupération du mode et remplacement des NA par le mode
#'Function that replaces the NA with the mode
#'
#' @param v a vector containing the NA values
#'
#' @return
#' @export
#'
#' @examples
getmode <- function(v) {
  uniqv <- unique(v)
  tidyr::replace_na(v,uniqv[which.max(tabulate(match(v, uniqv)))])
}



#' Transformation function on qualitative variables
#'
#' @param d dataset containing qualitative predictor variables
#'
#' @return  qualitative variables recoded in 0/1
#' @export
#'
#' @examples
#'
transformQuali <- function(d)
{
  # Récupérer la liste des variables explicatives qualitatives et les recoder en 0/1
  id_quali = sapply(d, function(x){is.factor(x)})
  if (sum(id_quali)>0)
  {
    quali = as.data.frame(d[id_quali])
    quali <- as.data.frame(apply(quali,2,getmode))
    quali = fastDummies::dummy_cols(quali, remove_selected_columns = TRUE, remove_first_dummy=TRUE)
  } else
  {
    quali <- NULL
  }
  return(quali)
}

#' Transformation function on quantitative variables
#'
#' @param d dataset containing qualitative predictor variable
#'
#' @return the NA values of the quantitative variables replaced by the average of each variable
#' @export
#'
#' @examples
transformQuanti <- function(d)
{
  #Récupérer la liste des variables explicatives quantitatives
  id_quanti = sapply(d,function(x){is.numeric(x)|is.double(x)})
  if (sum(id_quanti)>0)
  {
    quanti = as.data.frame(d[id_quanti])
    quanti <- replace(quanti, TRUE, lapply(quanti, function(x) replace(x, is.na(x), mean(x, na.rm = TRUE))))
  } else
  {
    quanti <- NULL
  }
  return(quanti)
}


#' the function that groups together the quantitative and qualitative variables
#'
#' @param qual qualitative variables
#' @param quant quantitative variables
#'
#' @return a matrix of predictor variables
#' @export
#'
#' @examples
combine <- function(qual, quant)
{
  # Recombiner les explicatives
  if (is.null(qual)){
    expli <- quant
  } else if (is.null(quant)) {
    expli <- qual
  } else {
    expli <- cbind(qual, quant)
  }
  return(expli)
}

# Fonction de vérification des données
#' Checkdata function
#'
#' @param expli predictor variables
#' @param cible target variable
#'
#' @return x and y tranformed
#' @export
#'
#' @examples
tranformDataset<- function(expli, cible)
{

  # Recoder la variable cible en 0/1 si ce n'est pas le cas
  if (is.factor(cible) | length(unique(cible))==2)
  {
    cible = as.factor(cible)
    w <- levels(cible)
    cible<-fastDummies::dummy_cols(cible)
    cible<-as.matrix(cible[,3])
    print(paste(w[1], "correspond a la modalite 0"))
    print(paste(w[2], "correspond a la modalite 1"))
  }

  # Transformer les variables explicatives charactères en factor
  donnees = as.data.frame(unclass(expli), stringsAsFactor = TRUE, col.names = names(expli))

  qual = transformQuali(donnees)
  quant = transformQuanti(donnees)

  result = combine(qual, quant)
  return(list(x = result, y = cible))
}





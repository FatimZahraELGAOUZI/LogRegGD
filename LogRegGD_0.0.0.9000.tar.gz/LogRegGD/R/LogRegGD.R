#source("R/Check_Data.R")
#source("R/LogisticReg_GradDesc.R")

#Messages d'erreur
ERREUR_TYPE_DATA="The input is not a dataframe"
ERREUR_FORMULA="Formula must be R formula !"
TYPE_MODES <- c('batch','online','mini-batch')
MODE_POSSIBLES = "the possible modes : "
ERREUR_MODE_INCORRECT="Incorrect mode"
ERREUR_BATCH_SIZE="The batch-size must be positive and does not exceed the number of data"
ERREUR_NOMBRE_MODALITE="Target variable has more than 2 modalities"
ERREUR_ITER_MAX="max_iter must imperatively be positive"




#Definition classe
definitionClasse <- list(model=NULL)
class(definitionClasse ) <- "CalculLogRegGD"

#' @Title  Fit function
#'
#' @param formula an object of class "formula" (or one that can be coerced to that class): a symbolic description of the model to be fitted.“formula” describes the problem to be solved and must correspond to “target ~feature_1 + feature_2” if explanatory are explicitly specified, or “target ~ .” if all available variables
#' @param data the dataframe containing the variables in the model
#' @param mode the mode chosen to be used to update coefficients of stochastic gradient descent.We have 3 posiblities: {« batch », « online », « mini_batch »}
#' @param batch_size is the number of observations for the mini-batch mode
#' @param max_iter is the number of iterations
#' @param tol is the minimum movement allowed for each iteration
#' @param eta is the learning rate for gradient descent
#' @param ncores indicates the number of cores to be used in parallel programming
#'
#' @return The function returns an object of TYPE S3 that will be used later in the prediction function
#'
#' @export
#'
fit <- function(formula, data, mode="batch", ncores=NULL, max_iter = 500, tol = 1e-3, eta = 0.3, batch_size = 32)
{
  #On en profite pour introduire les contrôles
  #Contrôles:
  controlerFormula(formula)
  controlerDataType(data)
  controlerMode(mode)
  controlerItermax(max_iter)
  batch_size=controlerBatch(batch_size, data,mode)
  ncores=ncores(ncores)

  #Récupération et transformation des x et y
  y = formule_extract_cible(formula, data)
  xtemp = formule_donnees_exp(formula, data)
  data = tranformDataset(xtemp,y)
  x = data[["x"]]
  y = data[["y"]]

  #Creation de l'instance
  instance <- list(call=NULL,model=NULL,coefficient=NULL,formula=NULL,y=NULL,modalites= NULL,iter=NULL,mode=NULL,var=NULL,var_names=NULL, resdev = NULL, resdf = NULL, totdf = NULL, aic = NULL)
  #le modele
  instance$model= GradDescente(x, y, eta = eta, max_iter = max_iter, tol = tol, mode_desc=mode, batch_size=batch_size, nc = ncores)
  #l'appel à fonction fit
  call<-match.call()
  instance$call=call
  #les coefficients
  instance$coefficient=instance$model$coef
  #la formule
  instance$formula=formula
  #la variable à expliquer
  instance$y=y
  #le nombre de variables explicatives
  instance$var <- ncol(x)
  #les noms des variables explicatives
  instance$var_names <- colnames(x)
  #Les moyennes et les ecarts-types des variables explicatives
  instance$Xmeans <- apply(x, 2, mean)
  instance$Xsd<-apply(x, 2, sd)
  # le nombre d'iteration
  instance$iter=instance$model$nbIter
  # le mode de descente de gradient
  instance$mode = controlerMode(mode)
  # deviance residuelle
  instance$resdev = instance$model$dev
  instance$resdf = nrow(x)-(length(instance$coefficient)-1)-1
  #deviance nulle
  instance$totdf = nrow(x)-1
  # AIC
  instance$aic= instance$resdev + 2*length(instance$coefficient)

  class(instance) <- "CalculLogRegGD"

  return(instance)
}

############################################################ Surcharge Print #####################################################

#' the generic "print" method
#'
#' @param objet is the fitted object
#'
#' @return
#' @export
#'
#' @examples


print.CalculLogRegGD <- function(objet)
{
  cat("############################################################################################################### \n")
  cat("\n")
  cat("Call : \n", paste(deparse(objet$call), sep = "\n", collapse = "\n"), "\n\n", sep = "")
  print(objet$formula)
  cat("Nombre de variables explicatives : ", objet$var, "\n")
  cat("Noms des variables : ", objet$var_names,"\n")
  cat("Nombre d'itérations : ", objet$iter, "\n")
  print("Coefficients :")
  print(objet$coefficient)
  cat("Residual deviance : ", objet$resdev, "\n")
  cat("Degrees of freedom (residual) : ", objet$resdf, "\n")
  cat("Degrees of freedom (total) : ", objet$totdf, "\n")
  cat("AIC : ", objet$aic, "\n")
  cat("\n")
  cat("############################################################################################################### \n")

}

############################################################ Surcharge summary ###############################################
#' the generic "Summary" method
#'
#' @param objet is the fitted object
#'
#' @return
#' @export
#'
#' @examples
#'
summary.CalculLogRegGD <- function(objet)
{
  cat("############################################################################################################### \n")
  cat("\n")
  cat("Call : \n", paste(deparse(objet$call), sep = "\n", collapse = "\n"), "\n\n", sep = "")
  print(objet$formula)
  print("Coefficients :")
  print(objet$coefficient)
  cat("Gradient descent : ", objet$mode, "\n")
  cat("Nombre de variables explicatives : ", objet$var, "\n")
  cat("Noms des variables : ", objet$var_names,"\n")
  cat("Nombre d'itérations : ", objet$iter, "\n")
  cat("Residual deviance : ", objet$resdev, "\n")
  cat("Degrees of freedom (residual) : ", objet$resdf, "\n")
  cat("Degrees of freedom (total) : ", objet$totdf, "\n")
  cat("AIC : ", objet$aic, "\n")
  cat("\n")
  cat("############################################################################################################### \n")

}


################################################### Les fonctions de controles ################################################################

#' Formula's Control function
#'
#' @param formula a symbolic description of the model to be fitted
#'
#' @return Error message:"Formula must be R formula !"
#' @export
#'
#' @examples
controlerFormula <- function(formula)
{
  if(plyr::is.formula(formula)==F)
  {
    stop(ERREUR_FORMULA)
  }
}


#' DataType's Control function
#'
#' @param data the dataframe containing the variables in the model
#'
#' @return Error message:"The input is not a dataframe !"
#' @export
#'
#' @examples
#'
controlerDataType <- function (data)
{
  if (is.data.frame(data)==FALSE)
  {
    stop(ERREUR_TYPE_DATA)
  }
}


#' Mode's Control function
#'
#' @param mode the mode chosen to be used to update coefficients of stochastic gradient descent
#'
#' @return Error message:"Incorrect mode" and the list of possible modes
#' @export
#'
#' @examples
controlerMode<-function(mode)
{
  if(is.na (match(mode,TYPE_MODES)))
  {
    print (MODE_POSSIBLES)
    print (TYPE_MODES)
    stop(ERREUR_MODE_INCORRECT)
  }
}

#' the target modality control function
#'
#' @param y the target variable
#'
#' @return Error message:"The target variable has more than 2 modalities"
#' @export
#'
#' @examples
controlerNombreModalites<-function(y)
{
  if(length(unique(y))!=2)
  {
    stop (ERREUR_NOMBRE_MODALITE)
  }
}

#' Batch_Size's Control function
#'
#' @param batch_size is the number of observations for the mini-batch mode
#' @param donnees is the dataset
#' @param mode the mode chosen to be used to update coefficients of stochastic gradient descent
#'
#' @return Error message:"The batch-size must be positive and does not exceed the number of data"
#' @export
#'
#' @examples

controlerBatch<-function(batch_size,donnees,mode)
{
  if(mode=="online" | mode == "batch")
  {
    return (NULL);
  }
  if( batch_size>=nrow(donnees) || batch_size<0 )
  {
    stop (ERREUR_BATCH_SIZE)
  }
}


#' max_iter's Control function
#'
#' @param max_iter is the number of iterations
#'
#' @return Error message:"max_iter must imperatively be positive"
#' @export
#'
#' @examples
controlerItermax<-function(max_iter)
{
  if( max_iter <0)
  {
    stop (ERREUR_ITER_MAX)
  }
}

#' Title
#'
#' @param formula a symbolic description of the model to be fitted
#' @param donnees the dataset
#'
#' @return the explanatory variables
#' @export
#'
#' @examples
formule_donnees_exp<- function (formula, donnees)
{
  # recuperation des variables explicatives (right of tilde)
  x <- model.frame(formula, donnees, na.action = na.pass)
  x = subset.data.frame(x, select = -1)
  return (x)
}

#' Title
#'
#' @param formula a symbolic description of the model to be fitted
#' @param donnees the dataset
#'
#' @return the target variable
#' @export
#'
#' @examples
formule_extract_cible<- function (formula, donnees)
{
  # recuperation de Y (left of tilde)
  var<-model.frame(formula,donnees, na.action = na.pass)
  # controler Y
  Y<-as.matrix.data.frame(var[1])
  controlerNombreModalites(Y)
  return (Y)
}



#Recuperation et controle des coeurs

#' Function to control and get cores
#'
#' @param cores_choice the number of CPU cores chosen by the user
#'
#' @return cores_choice the number of CPU cores that will be used in parallelisation
#' @export
#'
#' @examples
ncores<-function(cores_choice)
{

  if (is.null(cores_choice))
  {
    cores_choice = 1
  } else if (cores_choice >= parallel::detectCores() || cores_choice <= 0 )
    {
      cores_choice = parallel::detectCores()-1
    } else
    {
    cores_choice = cores_choice
    }
  return (cores_choice)
}


######################################################## Fonction Predict ###############################################

#' Predict function
#'
#' @param objet_Reg is a S3 object provided by the function fit()
#' @param newdata the dataframe (DataTest) that we will use to make the prediction
#' @param type indicates the type of prediction {“class”: predicted class , “posterior”:belonging class probability}
#'
#' @return Function that return a list (the predicted probs,confusion matrix and error rate) or the belonging class probability
#' @export
#'
#' @examples

predict<-function (objet_Reg, newdata, type)
{
  #controle de l'objet
  if (class(objet_Reg)!="CalculLogRegGD")
  {
    stop("Object's class is not CalculLogRegGD")
  }

  # controle des données
  # if (length(intersect(objet_Reg$var_names,colnames(newdata))) != objet_Reg$var)
  # {
  #   stop("Nombre de variables differents")
  # }

  # recuperer x et y
  px = formule_donnees_exp(objet_Reg$formula, newdata)
  py = formule_extract_cible(objet_Reg$formula, newdata)

  #transformation des données
  #oldmode = objet_Reg$Statmode
  pquali = transformQuali(px) # remplacer NA quali par mode
  pquanti = transformQuanti(px) # on remplace les NA par mean(newdata)


  #centrer et reduire
  # Recuperation des moyennes et des ecarts types des donnees
  means <- objet_Reg$Xmeans#[colnames(pquanti)]
  stdvs<-objet_Reg$Xsd#[colnames(pquanti)]

  # On utilise les moyennes et les ecarts types des donnees d'entrainement pour centrer et reduire les données tests
  #pquant<- apply(pquanti,1,function(x){(x-means)/sd})
  res = as.data.frame(combine(pquali,pquanti))
  res = sweep(sweep(res, 2L, means), 2, stdvs, "/")


  newdata = as.data.frame(cbind(res,py))
  x = as.data.frame(newdata[,intersect(objet_Reg$var_names, colnames(newdata))])
  y = as.data.frame(newdata[, !colnames(newdata) %in% colnames(x)])
  colnames(y) = "y"

  #récupérer les variables dans l'ordre
  pnewdata <- x[objet_Reg$var_names]

  #Ajouter l'intercept
  pnewdata<-cbind(Intercept=(rep(1,nrow(pnewdata))), pnewdata)

  #calculer les proba
  coefficient <-as.vector(objet_Reg$coefficient)
  pnewdata<-as.matrix(pnewdata)
  pi <- RegLogFonction(pnewdata %*% coefficient)

  if (type=="class")
  {
    #classe prédite
    pred = ifelse(pi>=0.5,1,0)
    mc = table(as.matrix(y), pred)
    err = 1.0-sum(diag(mc))/sum(mc)
    return(list(pred = pred, mat_conf = mc, error = err))
  }
  else if (type=="posterior")
  {
    # probabilité d’appartenance aux classes
    pred <- pi
    return(pred = pred)
  }
}

#reflexion
# data = read.csv("pima-indians-diabetes.csv", header = T, sep=',')
# dt = sample(nrow(data), nrow(data)*.7)
# train<-data[dt,]
# test<-data[-dt,]
#
# system.time(obj <- fit(X9 ~ ., train, mode="batch", ncores = 3, max_iter = 100))
# print(obj)
# system.time(p <- predict(obj, test, "class"))
# p$mat_conf
# p$error
# summary(obj)
# system.time(obj2 <- fit(X9 ~ ., pima_indians_diabetes, mode="batch"))
# print(obj2)
# summary(obj2)
# d = data.frame(cbind(scale(pima_indians_diabetes[,1:8]),pima_indians_diabetes$X9))
# model<-glm(V9~.,family=binomial,data=d)
# print(model)

# library(liver)
#data("adult")
# adult[adult=="?"] <- NA
# levels(droplevels(adult$workclass))
# system.time(obj <- fit(income ~ age + workclass + demogweight + gender, adult, mode="batch", ncores = 4, tol = 1e-2, max_iter = 100))
# print(obj)
# summary(obj)
# system.time(obj2 <- fit(income ~ age + workclass + demogweight + gender , adult, mode="batch", tol = 1e-2, max_iter = 100))
# print(obj2)
# summary(obj2)
# system.time(obj3 <- fit(income ~ age + workclass + demogweight + gender  , adult, mode="online"))
# obj3
# system.time(obj4 <- fit(income ~ age + workclass + demogweight + gender , adult, mode="mini-batch"))
# summary(obj4)
# ind <- sapply(adult, is.numeric)
# adult[ind] <- lapply(adult[ind], scale)
# model<-glm(income~ age + workclass + demogweight + gender,family=binomial,data=adult)
# print(model)

# d = read.csv("Test.csv", header = T, sep=";", dec = ",")
# obj=fit(diabete ~ ., d, mode="online")
# print(obj)
# d$diabete = dplyr::recode(d$diabete, "presence"=1, "absence"=0)
# d$triceps = replace(d$triceps, is.na(d$triceps), mean(d$triceps, na.rm = TRUE))
# d = as.data.frame(cbind(scale(d[,1:8]),d$diabete))
# model<-glm(V9~ .,family=binomial,data=d)
# model$coefficients

# num_params = length(obj$coef) + 1
# print(num_params)
# tc <- lapply(obj$var,function(x,y){return(log(prop.table(table(y,x)+1,1)))},obj$y)
# aic = 2* log(tc) + 2 * 10
